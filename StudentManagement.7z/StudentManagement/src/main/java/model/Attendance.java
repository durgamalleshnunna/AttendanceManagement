package model;

public class Attendance {
    private String studentId;
    private String date, status;

    public Attendance(String studentId, String date, String status) {
        this.studentId = studentId;
        this.date = date;
        this.status = status;
    }

    public String getStudentId() { return studentId; }
    public String getDate() { return date; }
    public String getStatus() { return status; }
}

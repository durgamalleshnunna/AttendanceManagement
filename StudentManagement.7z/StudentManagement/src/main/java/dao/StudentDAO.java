package dao;
import java.sql.*;
import java.util.*;
import model.Student;

public class StudentDAO {
    public static List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM students");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Student(rs.getInt("id"), rs.getString("name"), rs.getString("email"), rs.getString("phone"), rs.getString("batch")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}

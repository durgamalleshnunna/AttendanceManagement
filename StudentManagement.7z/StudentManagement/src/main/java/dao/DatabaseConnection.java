package dao;
import java.sql.*;

public class DatabaseConnection {
    private static Connection conn;
    
    public static Connection getConnection() {
        try {
            if (conn == null) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance_db", "root", "root");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
}

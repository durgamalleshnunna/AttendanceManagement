package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DatabaseConnection;
import model.Attendance;

@WebServlet("/AttendanceServlet")
public class MarkAttendanceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public MarkAttendanceServlet() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String studentId = request.getParameter("studentId");
        String date = request.getParameter("date");
        String status = request.getParameter("status");

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("INSERT INTO attendance(student_id, date, status) VALUES(?, ?, ?)");
            ps.setString(1, studentId);  // Changed from int to String
            ps.setString(2, date);
            ps.setString(3, status);

            int result = ps.executeUpdate();
            if (result > 0) {
                request.setAttribute("message", "Attendance marked successfully!");
            } else {
                request.setAttribute("error", "Failed to mark attendance.");
            }
            request.getRequestDispatcher("admin_dashboard.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Attendance> attendanceList = new ArrayList<>();
        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM attendance");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                attendanceList.add(new Attendance(rs.getString("student_id"), rs.getString("date"), rs.getString("status")));  // Changed from int to String
            }
            request.setAttribute("attendanceList", attendanceList);
            request.getRequestDispatcher("attendance_list.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
